-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 15, 2016 at 05:42 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `carsearch`
--

-- --------------------------------------------------------

--
-- Table structure for table `maruticiazvariants`
--

CREATE TABLE IF NOT EXISTS `maruticiazvariants` (
  `vname` varchar(30) NOT NULL,
  `length` varchar(10) NOT NULL,
  `width` varchar(10) NOT NULL,
  `height` varchar(10) NOT NULL,
  `clearance` varchar(10) NOT NULL,
  `torque` varchar(10) NOT NULL,
  `displacement` varchar(10) NOT NULL,
  `power` int(5) NOT NULL,
  `cylinders` int(5) NOT NULL,
  `mhighway` varchar(10) NOT NULL,
  `mcity` varchar(10) NOT NULL,
  `moverall` varchar(10) NOT NULL,
  `tyres` varchar(10) NOT NULL,
  `wsize` int(5) NOT NULL,
  `wtype` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maruticiazvariants`
--

INSERT INTO `maruticiazvariants` (`vname`, `length`, `width`, `height`, `clearance`, `torque`, `displacement`, `power`, `cylinders`, `mhighway`, `mcity`, `moverall`, `tyres`, `wsize`, `wtype`) VALUES
('Maruti Ciaz VXi', '4490mm', '1730mm', '1485mm', '170mm', '130 Nm @ 4', '1373 cc', 91, 4, '16 kmpl', '11 kmpl', '13 kmpl', '185/65 R15', 15, 'Steel'),
('Maruti Ciaz VXi (o)', '4490 mm', '1730 mm', '1485 mm', '170 mm', '130 Nm @ 4', '1373 cc', 91, 4, '0 kmpl', '0 kmpl', '0 kmpl', '185/65 R15', 15, 'Steel'),
('Maruti Ciaz ZXi+ AT', '4490 mm', '1730 mm', '1485 mm', '170 mm', '130 Nm @ 4', '1373 cc', 92, 4, '16 kmpl', '0 kmpl', '0 kmpl', '195/55 R16', 16, 'Alloy'),
('Maruti Ciaz ZXi+', '4490 mm', '1730 mm', '1485 mm', '170 mm', '130 Nm @ 4', '1373 cc', 91, 4, '16 kmpl', '11 kmpl', '13 kmpl', '195/55 R16', 16, 'Alloy'),
('Maruti Ciaz ZXi+ RS', '4505 mm', '1730 mm', '1485 mm', '170 mm', '130 Nm @ 4', '1373 cc', 91, 4, '0 kmpl', '0 kmpl', '0 kmpl', '195/55 R16', 16, 'Alloy'),
('Maruti Ciaz ZXi AT', '4490 mm', '1730 mm', '1485 mm', '170 mm', '130 Nm @ 4', '1373 cc', 91, 4, '14.8 kmpl', '10 kmpl', '19.12 kmpl', '185/65 R15', 15, 'Alloy');

-- --------------------------------------------------------

--
-- Table structure for table `marutivitaravariants`
--

CREATE TABLE IF NOT EXISTS `marutivitaravariants` (
  `vname` varchar(30) NOT NULL,
  `length` varchar(10) NOT NULL,
  `width` varchar(10) NOT NULL,
  `height` varchar(10) NOT NULL,
  `clearance` varchar(10) NOT NULL,
  `torque` varchar(10) NOT NULL,
  `displacement` varchar(10) NOT NULL,
  `power` varchar(5) NOT NULL,
  `cylinders` int(5) NOT NULL,
  `mhighway` varchar(10) NOT NULL,
  `mcity` varchar(10) NOT NULL,
  `moverall` varchar(10) NOT NULL,
  `tyres` varchar(10) NOT NULL,
  `wsize` varchar(10) NOT NULL,
  `wtype` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marutivitaravariants`
--

INSERT INTO `marutivitaravariants` (`vname`, `length`, `width`, `height`, `clearance`, `torque`, `displacement`, `power`, `cylinders`, `mhighway`, `mcity`, `moverall`, `tyres`, `wsize`, `wtype`) VALUES
('Maruti Vitara Brezza LDi', '3395 mm', '1790 mm', '1640 mm', '198 mm', '200', '1248 cc', '88.5', 4, '24.3 kmpl', '20.8 kmpl', '0 kmpl', '205/60 R16', '16 Inch', 'Steel'),
('Maruti Vitara VDi', '3995 mm', '1790 mm', '1640 mm', '198 mm', '200 ', '1248 cc', '88.5', 4, '24.3 kmpl', '20.8 kmpl', '0 kmpl', '205/60 R16', '16 inch', 'Steel'),
('Maruti Vitara Brezza ZDi', '3995 mm', '1790 mm', '1640 mm', '198 mm', '200', '1248 cc', '88.5', 4, '24.3 kmpl', '20.8 kmpl', '0 kmpl', '205/60 R16', '16 Inch', 'Alloy'),
('Maruti Vitara Brezza ZDi Plus', '3995 mm', '1790 mm', '1640 mm', '198 mm', '200', '1648 cc', '88.5', 4, '24.3 kmpl', '20.8 kmpl', '0 kmpl', '', '', ''),
('Maruti Vitara Brezza LDi Optio', '3995 mm', '1790 mm', '1640 mm', '198 mm', '200', '1248 cc', '88.4', 4, '24.3 kmpl', '20.8 kmpl', '0 kmpl', '205/60 R16', '16 Inch', 'Steel'),
('', '', '', '', '', '', '', '', 0, '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `maruti_alto_variants_k10`
--

CREATE TABLE IF NOT EXISTS `maruti_alto_variants_k10` (
  `vname` varchar(30) NOT NULL,
  `length` varchar(10) NOT NULL,
  `width` varchar(10) NOT NULL,
  `height` varchar(10) NOT NULL,
  `clearance` varchar(10) NOT NULL,
  `torque` varchar(10) NOT NULL,
  `displacement` varchar(10) NOT NULL,
  `power` varchar(10) NOT NULL,
  `cylinders` int(10) NOT NULL,
  `mhighway` varchar(10) NOT NULL,
  `mcity` varchar(10) NOT NULL,
  `moverall` varchar(10) NOT NULL,
  `tyres` varchar(10) NOT NULL,
  `wsize` varchar(10) NOT NULL,
  `wtype` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maruti_alto_variants_k10`
--

INSERT INTO `maruti_alto_variants_k10` (`vname`, `length`, `width`, `height`, `clearance`, `torque`, `displacement`, `power`, `cylinders`, `mhighway`, `mcity`, `moverall`, `tyres`, `wsize`, `wtype`) VALUES
('Maruti Alto K10 LX', '3545 mm', '1490 mm', '1475 mm', '160 mm', '90 ', '998 cc', '67.1', 3, '24.07 kmpl', '20.6 kmpl', '20.5 kmpl', '155/65 R13', '13 inch', 'Steel'),
('Maruti Alto K10 VXI AMT', '3545 mm', '1490 mm', '1475 mm', '160 mm', '90 ', '998 cc', '67.1 ', 3, '24.7 kmpl', '20.6 kmpl', '20.5 kmpl', '155/65 R13', '13 inch', 'Steel'),
('Maruti Alto K10 VXI', '3545 mm', '1490 mm', '1475 mm', '160 mm', '90', '998 cc', '67.1', 3, '24.07 kmpl', '20.6 kmpl', '20.5 kmpl', '155/65 R13', '13 inch', 'Steel'),
('Maruti Alto K10 LXI', '3545 mm', '1490 mm', '1475 mm', '160 mm', '90', '998 cc', '67.1', 3, '24.07 kmpl', '20.6 kmpl', '20.5 kmpl', '155/65 R13', '13 inch', 'Steel'),
('Maruti Alto K10 LXI CNG', '3545 mm', '1490 mm', '1475 mm', '160 mm', '78', '998 cc', '58.2', 3, '24.07 kmpl', '28 kmpl', '0 kmpl', '155/65 R13', '13 inch', 'Steel');

-- --------------------------------------------------------

--
-- Table structure for table `maruti_celerio_variants`
--

CREATE TABLE IF NOT EXISTS `maruti_celerio_variants` (
  `vname` varchar(30) NOT NULL,
  `length` varchar(10) NOT NULL,
  `width` varchar(10) NOT NULL,
  `height` varchar(10) NOT NULL,
  `clearance` varchar(10) NOT NULL,
  `torque` varchar(10) NOT NULL,
  `displacement` varchar(10) NOT NULL,
  `power` varchar(10) NOT NULL,
  `cylinders` int(10) NOT NULL,
  `mhighway` varchar(10) NOT NULL,
  `mcity` varchar(10) NOT NULL,
  `moverall` varchar(10) NOT NULL,
  `tyres` varchar(10) NOT NULL,
  `wsize` varchar(10) NOT NULL,
  `wtype` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maruti_celerio_variants`
--

INSERT INTO `maruti_celerio_variants` (`vname`, `length`, `width`, `height`, `clearance`, `torque`, `displacement`, `power`, `cylinders`, `mhighway`, `mcity`, `moverall`, `tyres`, `wsize`, `wtype`) VALUES
('Maruti Celerio ZXI AT', '3600 mm', '1600 mm', '1560 mm', '165 mm', '90', '998 cc', '67.04 ', 3, '23.1 kmpl', '20 kmpl', '17.5 kmpl', '165/70 R14', '14 inch', 'Steel'),
('Maruti Celerio ZDi', '3600 mm', '1600 mm', '1560 mm', '165 mm', '125', '793 cc', '47', 2, '23.1 kmpl', '23.8 kmpl', '23.5 kmpl', '165/70 R14', '14 inch', 'Steel'),
('Maruti Celerio VDi', '3600 mm', '1600 mm', '1560 mm', '165 mm', '125', '793 cc', '47', 2, '23.1 kmpl', '23.8 kmpl', '23.5 kmpl', '165/70 R14', '14 inch', 'Steel'),
('Maruti Celerio Green VXI', '3600 mm', '1600 mm', '1560 mm', '165 mm', '78', '998 cc', '58.2', 3, '23.1 kmpl', '26.02 kmpl', '0 kmpl', '165/70 R14', '14 inch', 'Steel');

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE IF NOT EXISTS `model` (
  `iid` int(5) NOT NULL AUTO_INCREMENT,
  `company` varchar(25) NOT NULL,
  `model` varchar(25) NOT NULL,
  PRIMARY KEY (`iid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=163 ;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`iid`, `company`, `model`) VALUES
(1, 'Maruti', 'CiaZ'),
(2, 'Maruti', 'Grand vitara 2009-2015'),
(3, 'Maruti', 'Gypsy'),
(4, 'Maruti', 'Omni'),
(5, 'Maruti', 'Eeco'),
(6, 'Maruti', 'Vitara Breeza'),
(7, 'Maruti', 'WagonR'),
(8, 'Maruti', 'Ritz'),
(9, 'Maruti', 'WagonR Stingray'),
(10, 'Maruti', 'Swift'),
(11, 'Maruti', 'Celerio'),
(12, 'Maruti', 'Swift Dzire Tour'),
(13, 'Maruti', 'S-Cross'),
(14, 'Maruti', 'Alto K10'),
(15, 'Maruti', 'Swift Dzire'),
(16, 'Maruti', 'Balena'),
(17, 'Maruti', 'Alto 800'),
(18, 'Maruti', 'Eritga'),
(19, 'Hyundai', 'i10'),
(20, 'Hyundai', 'Eon'),
(21, 'Hyundai', 'Santa Fe'),
(22, 'Hyundai', 'Creta'),
(23, 'Hyundai', 'Grand i10'),
(24, 'Hyundai', 'Elantra'),
(25, 'Hyundai', 'Elite i20'),
(26, 'Hyundai', 'Xcent'),
(27, 'Hyundai', 'Verna 45'),
(28, 'Hyundai', 'i20 Active'),
(29, 'Honda', 'Brio'),
(30, 'Honda', 'CR-V'),
(31, 'Honda', 'Jazz'),
(32, 'Honda', 'Mobilio'),
(33, 'Honda', 'City'),
(34, 'Honda', 'BR-V'),
(35, 'Honda', 'Amaze'),
(36, 'Toyota', 'Prius'),
(37, 'Toyota', 'Fortuner'),
(38, 'Toyota', 'Innova'),
(39, 'Toyota', 'Coralla Altis'),
(40, 'Toyota', 'Etias Cross'),
(41, 'Toyota', 'Land Crusier Prade'),
(42, 'Toyota', 'Etios'),
(43, 'Toyota', 'Etios Liva'),
(44, 'Toyota', 'Innova Crysta'),
(45, 'Toyota', 'Camry'),
(46, 'Toyota', 'Land Crusier'),
(47, 'Tata', 'Xenon XT'),
(48, 'Tata', 'Indica eV2'),
(49, 'Tata', 'Safari'),
(50, 'Tata', 'Winger'),
(51, 'Tata', 'Venture'),
(52, 'Tata', 'Zest'),
(53, 'Tata', 'Movus'),
(54, 'Tata', 'Aria'),
(55, 'Tata', 'Sumo Gold'),
(56, 'Tata', 'Indigo eCS'),
(57, 'Tata', 'Bolt'),
(58, 'Tata', 'Nano'),
(59, 'Tata', 'Tiago'),
(60, 'Tata', 'Safari Storme'),
(61, 'Mahindra', 'Scorpio Getaway'),
(62, 'Mahindra', 'Genio'),
(63, 'Mahindra', 'Verito Vibe'),
(64, 'Mahindra', 'Bolero'),
(65, 'Mahindra', 'e20'),
(66, 'Mahindra', 'KUV100'),
(67, 'Mahindra', 'Scorpio'),
(68, 'Mahindra', 'Verito'),
(69, 'Mahindra', 'Xylo'),
(70, 'Mahindra', 'NuvoSport'),
(71, 'Mahindra', 'Thar'),
(72, 'Mahindra', 'XUV500'),
(73, 'Mahindra', 'TUV300'),
(74, 'Mahindra', 'e Verito'),
(75, 'Ford', 'Endeavour'),
(76, 'Ford', 'Fiesta'),
(77, 'Ford', 'Figa'),
(78, 'Ford', 'Figo Aspire'),
(79, 'Ford', 'Eco Sport'),
(80, 'Chevrolet', 'Optra Magnum'),
(81, 'Chevrolet', 'Sail'),
(82, 'Chevrolet', 'Tavera Neo 3'),
(83, 'Chevrolet', 'TrailBlazer'),
(84, 'Chevrolet', 'Spark'),
(85, 'Chevrolet', 'Sail Sedam'),
(86, 'Chevrolet', 'Captiva'),
(87, 'Chevrolet', 'Beat'),
(88, 'Chevrolet', 'Cruze'),
(89, 'Chevrolet', 'Enjoy'),
(90, 'Volkswagen', 'Vento'),
(91, 'Volkswagen', 'Beetle'),
(92, 'Volkswagen', 'Ameo'),
(93, 'Volkswagen', 'Jetta'),
(94, 'Volkswagen', 'Polo'),
(95, 'Audi', 'A3'),
(96, 'Audi', 'A4'),
(97, 'Audi', 'RS5'),
(98, 'Audi', 'S6'),
(99, 'Audi', 'Q5'),
(100, 'Audi', 'S4'),
(101, 'Audi', 'A8'),
(102, 'Audi', 'S5'),
(103, 'Audi', 'Q7'),
(104, 'Audi', 'A6'),
(105, 'Audi', 'Q3'),
(106, 'Audi', 'TT'),
(107, 'Audi', 'RS7'),
(108, 'Audi', 'R8'),
(109, 'Audi', 'RS6 Avant'),
(110, 'BMW', 'X3'),
(111, 'BMW', '3 Series GT'),
(112, 'BMW', '3 Series'),
(113, 'BMW', 'X5'),
(114, 'BMW', 'Z4'),
(115, 'BMW', 'i8'),
(116, 'BMW', '5 Series'),
(117, 'BMW', 'X 6'),
(118, 'BMW', '7 Series'),
(119, 'BMW', '4 Series'),
(120, 'BMW', '6 Series'),
(121, 'BMW', 'X1'),
(122, 'BMW', '1 Series'),
(123, 'Renault', 'Pulse'),
(124, 'Renault', 'Lodgy'),
(125, 'Renault', 'Scala'),
(126, 'Renault', 'Fluence'),
(127, 'Renault', 'Kaleas'),
(128, 'Renault', 'Kwid'),
(129, 'Renault', 'Duster'),
(130, 'Nissam', 'Terrano'),
(131, 'Nissam', 'Sunny'),
(132, 'Nissam', 'Micra'),
(133, 'Nissam', 'Micra Active'),
(134, 'Skoda ', 'Octavia'),
(135, 'Skoda ', 'Yeti'),
(136, 'Skoda ', 'Rapid'),
(137, 'Skoda ', 'Superb'),
(138, 'Mercedes Benz', 'B class'),
(139, 'Mercedes Benz', 'CL class'),
(140, 'Mercedes Benz', 'GLC'),
(141, 'Mercedes Benz', 'E class'),
(142, 'Mercedes Benz', 'G class'),
(143, 'Mercedes Benz', 'CLA class'),
(144, 'Mercedes Benz', 'E63 class'),
(145, 'Mercedes Benz', 'S class'),
(146, 'Mercedes Benz', 'C class'),
(147, 'Mercedes Benz', 'GLA-class'),
(148, 'Mercedes Benz', 'CLS-class'),
(149, 'Mercedes Benz', 'AMG-class'),
(150, 'Mercedes Benz', 'GLE-class'),
(151, 'Mercedes Benz', 'A-class'),
(152, 'Mercedes Benz', 'GLS class'),
(153, 'Mercedes Benz', 'Mercedes Benz SLC'),
(154, 'Datsun', 'Go'),
(155, 'Datsun', 'Go plus'),
(156, 'Datsun', 'Redi-Go'),
(157, 'Fiat', '500'),
(158, 'Fiat', 'Punta EVO'),
(159, 'Fiat', 'Linea'),
(160, 'Fiat', 'Linea Classic'),
(161, 'Fiat', 'Punto Avventura'),
(162, 'Fiat', 'Punto Pure');

-- --------------------------------------------------------

--
-- Table structure for table `models`
--

CREATE TABLE IF NOT EXISTS `models` (
  `vname` varchar(30) NOT NULL,
  `length` varchar(10) NOT NULL,
  `width` varchar(10) NOT NULL,
  `height` varchar(10) NOT NULL,
  `clearance` varchar(10) NOT NULL,
  `torque` varchar(10) NOT NULL,
  `displacement` varchar(10) NOT NULL,
  `power` varchar(10) NOT NULL,
  `cylinders` varchar(10) NOT NULL,
  `mhighway` varchar(10) NOT NULL,
  `mcity` varchar(10) NOT NULL,
  `moverall` varchar(10) NOT NULL,
  `tyres` varchar(10) NOT NULL,
  `wsize` varchar(10) NOT NULL,
  `wtype` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `models`
--

INSERT INTO `models` (`vname`, `length`, `width`, `height`, `clearance`, `torque`, `displacement`, `power`, `cylinders`, `mhighway`, `mcity`, `moverall`, `tyres`, `wsize`, `wtype`) VALUES
('Maruti Ciaz ', '4490 mm', '1730 mm', '1485 mm', '170 mm', '130', '1373 cc', '91.1', '4', '20.73 kmpl', '16.7 kmpl', '13 kmpl', '185/65 R15', '15', 'Steel'),
('Maruti Gypsy', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA'),
('Maruti Omni', '3370 mm', '1410 mm', '1640 mm', '165 mm', '59', '796 cc', '34.2', '3', '19.7 kmpl', '12.6 kmpl', '13.7 kmpl', '145 R12 LT', '12', 'Steel'),
('Maruti Eeco', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA'),
('Maruti Ritz', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA'),
('Maruti Vitara Brezza', '3995 mm', '1790 mm', '1640 mm', '198 mm', '200 ', '1248 cc', '88.5', '4', '24.3 kmpl', '20.8 kmpl', '0 kmpl', '205/60 R16', '16', 'Steel'),
('Maruti Wagon R', '3599 mm', '1495 mm', '1700 mm', '165 mm', '90', '998 cc', '67.04', '3', '17.3 kmpl', '17.08 kmpl', '0 kmpl', '145/80 R13', '13', 'Steel'),
('Maruti Wagno R Stingray', '3636 mm', '1475 mm', '1670 mm', '165 mm', '90', '998 cc', '67.04', '3', '20.51 kmpl', '17.08 kmpl', '0 kmpl', '155/65 R14', '14', 'Steel'),
('Maruti Swift', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA'),
('Maruti Celerio', '300 mm', '1600 mm', '1560 mm', '165 mm', '90', '998 cc', '67.04', '3', '23.1 kmpl', '20 kmpl', '0 kmpl', '155/80 R 1', '13 ', 'Steel'),
('Maruti Alto K10', '3545 mm', '1490 mm', '1475 mm', '160 mm', '90', '998 cc', '67.1', '3', '24.07 kmpl', '20.6 kmpl', '20.5 kmpl', '155/65 R13', '13', 'Steel');
